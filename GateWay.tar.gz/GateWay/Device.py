class Device(object):

    def __init__(self, mac, ip, name):
        self.name = name  
        self.mac = mac  
        self.ip = ip 